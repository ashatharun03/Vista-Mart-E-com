const productCategory = [
    { id : 1, label : "New In Store", value : "new in store"},
    { id : 2, label : "Fruits& Vegetables", value : "fruits& vegetables"},
    { id : 3, label : "Dairy, Bread & Eggs", value : "dairy, bread & eggs"},
    { id : 4, label : "Atta, Rice, Oil & Dals", value : "Atta, Rice, Oil & Dals"},
    { id : 5, label : "Meats", value : "Meats"},
    { id : 6, label : "Masala& Dry Fruits", value : "masala&dryfruits"},
    { id : 7, label : "Tea, Coffee", value : "Tea, Coffee"},
    { id : 8, label : "Ice Creams &More", value : "Ice Creams &More"},
    { id : 9, label : "Frozen Food", value : "Frozen Food"},
    { id : 10, label : "Skincare", value : "Skincare"},
    { id : 11, label : "Makeup & Beauty", value : "Makeup & Beauty"},
    { id : 12, label : "Baby Care", value : "Baby Care"},
]


export default productCategory